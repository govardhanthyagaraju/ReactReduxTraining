//env.dev.js

export const environment = {
    CURRENCY: 'INR',
    GOOGLE_API_KEY: 'AIzaSyBgrZrTZRvr_M3bjbji4rTVb94vjSyWRFA',
    SIGN_IN: `https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key`,
    SIGN_UP: `https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key`,
    PRODUCTS_API: 'https://raw.githubusercontent.com/mdmoin7/Random-Products-Json-Generator/master/products.json'
};
