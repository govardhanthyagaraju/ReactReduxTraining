

const ERROR_MESSAGES = {
    required: () => `This field is required`,
    minlength: (param) => `Min ${param.length} chars is required`,
    maxlength: (param) => `Max allowed chars is ${param.length}`,
    pattern: (param) => `Incorrect format entered`
};

export const getErrorMsg = (err, errObj) => {
    return ERROR_MESSAGES[err](errObj);
}