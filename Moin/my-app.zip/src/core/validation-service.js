import { getErrorMsg } from "./validation-messages";

// valid:true, invalid:false
const requiredValidator = (value) => {
    return value !== '';
}

const minlengthValidator = (value, errObj) => {
    return value.length >= errObj['length'];
}

const maxlengthValidator = (value, errObj) => {
    return value.length <= errObj['length'];
}

const patternValidator = (value, errObj) => {
    return errObj['regex'].test(value);
}

const checkValidation = (value, err, errObj) => {
    switch (err) {
        case 'required':
            return requiredValidator(value);
        case 'minlength':
            return minlengthValidator(value, errObj);
        case 'maxlength':
            return maxlengthValidator(value, errObj);
        case 'pattern':
            return patternValidator(value, errObj);
    }
}

export const findAllErrors = (validators, value) => {
    if (!validators) { return []; }

    const errors = Object.keys(validators);
    let errorsOccured = [];
    for (let err of errors) {
        if (!checkValidation(value, err, validators[err])) {
            errorsOccured.push(getErrorMsg(err, validators[err]));
        }
    }
    return errorsOccured;
}