//npm i axios -S

// bit.ly/2Ee7HOL
import axios from 'axios';

const get = (api) => axios.get(api);

const post = (api, data) => axios.post(api, data);

const put = (api, data) => axios.put(api, data);

const del = (api) => axios.delete(api);

export { get, post, put, del };