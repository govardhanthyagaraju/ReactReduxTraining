import React from 'react';

class Demo extends React.Component {

    showAlert() {
        alert('hello from react');
    }

    render() {
        const name = 'Mike';
        return (
            <div>
                <p>hello from {name}</p>
                <p>{2 + 5}</p>
                <button onClick={this.showAlert}>Click Me</button>
            </div>
        );
    }
}
export default Demo;