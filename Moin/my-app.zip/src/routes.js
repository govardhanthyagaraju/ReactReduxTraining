import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Demo from './Demo';
import ProductList from './containers/ProductList';
import Checkout from './components/Checkout';
import ErrorPage from './components/ErrorPage';
import Cart from './containers/Cart';
import Login from './containers/Login';
import PrivateRoute from './components/PrivateRoute';
import { connect } from 'react-redux';

class AppRouter extends React.Component {
    render() {
        return (
            <Switch>
                <Route path="/" component={Demo} exact />
                <Route path="/products" component={ProductList} />
                <PrivateRoute path="/checkout/:orderId" component={Checkout}
                    isAuthenticated={this.props.user} />
                <Route path="/cart" component={Cart} />
                <Route path="/login" component={Login} />
                <Route component={ErrorPage} />
            </Switch>
        );
    }
}
const mapStateToProps = state => ({ user: state.user });
export default connect(mapStateToProps)(AppRouter);