import React from 'react';
import Product from '../components/Product';
import * as dataService from '../core/data-service';
import { environment } from '../config/env.dev';
import { connect } from 'react-redux';
import { addToCart } from '../_store/actions/cartActions';
import { setLoading } from '../_store/actions/commonActions';
import { compose } from 'redux';
import withLoading from '../hoc/loadingHOC';

class ProductList extends React.Component {
    state = { pList: [] };

    componentDidMount() {
        this.getProductsData();
    }

    getProductsData() {
        console.log(this.state.pList);
        //this.props.setLoading(true);
        dataService.get(environment.PRODUCTS_API)
            .then(
                res => {
                    console.log('response', res);
                    this.setState({ pList: res.data });
                    this.props.setLoading(false);
                }
            )
            .catch(
                err => {
                    console.log('error', err);
                    this.props.setLoading(false);
                }
            );
    }

    addToCart(item) {
        console.log('button clicked', this.props);
        this.props.addItem(item);
        this.props.history.push('/cart');
    }

    render() {
        const { pList } = this.state;
        return (
            <div className="row">
                <h1>{this.props.title}</h1>
                {
                    pList.map(
                        (prod, i) => <Product
                            pData={prod}
                            key={prod.productId}
                            cCode={this.props.currCode}
                            btnClick={() => this.addToCart(prod)} />
                    )
                }
            </div>
        )
    }
}
// connect(how to connect)(what to connect)
const mapStateToProps = (state) => ({
    currCode: state.currency,
    loading: state.loading
});
const mapDispatchToProps = (dispatch) => ({
    addItem: (item) => dispatch(addToCart(item)),
    setLoading: (s) => dispatch(setLoading(s))
})
export default compose(
    connect(mapStateToProps, mapDispatchToProps),
    withLoading
)(ProductList);