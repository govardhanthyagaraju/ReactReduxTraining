import React from 'react';
import { connect } from 'react-redux';
import CartItem from '../components/CartItem';
import { updateCart } from '../_store/actions/cartActions';

class Cart extends React.Component {
    state = { items: [] };

    updateState(qty, i) {
        let { items } = this.state;
        // find item by id
        // if exists update qty
        const index = items.findIndex((v) => v.productId === i.productId);
        if (index >= 0) {
            items[index].qty = qty;
        } else {
            // add item into the state
            items.push({ ...i, qty });
        }
        this.setState({ items });
    }

    render() {
        if (this.props.cart.length <= 0) {
            return <div className="alert alert-info">Your cart is empty</div>
        }

        return (
            <div>

                <table className="table table-bordered">
                    {
                        this.props.cart.map(
                            item => <CartItem
                                item={item}
                                code={this.props.code}
                                key={item.productId}
                                notifyChange={(v) => this.updateState(v, item)} />
                        )
                    }
                </table>
                <button onClick={() => this.props.updateCart(this.state.items)}>
                    Update Cart
                </button>
            </div>
        )
    }
}
const mapStateToProps = state => ({
    cart: state.cart,
    code: state.currency
});
const mapDispatchToProps = dispatch => ({
    updateCart: (c) => dispatch(updateCart(c))
});
export default connect(mapStateToProps, mapDispatchToProps)(Cart);