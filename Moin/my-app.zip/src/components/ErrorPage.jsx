import React from 'react';

const ErrorPage = (props) => {
    return (<h1>404 page not found</h1>);
}
export default ErrorPage;