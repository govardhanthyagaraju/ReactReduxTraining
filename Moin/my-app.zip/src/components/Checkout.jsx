import React from 'react';
import ShowErrors from './ShowErrors';
import querystring from 'querystringify';

class Checkout extends React.Component {
    state = { name: '' };
    emailRef = null;

    nameVals = {
        required: true, minlength: { length: 5 }
    };

    static getDerivedStateFromProps(newProps) {
        const params = querystring.parse(newProps.location.search);
        if (params.name) {
            return { name: params.name };
        }
        return null;
    }

    componentDidMount() {
        //console.log(querystring.parse(this.props.location.search));
    }

    submitData(e) {
        e.preventDefault();
        console.log('form submitted', this.state, this.emailRef.value);
    }

    render() {
        return (
            <form onSubmit={(e) => this.submitData(e)}>
                <label>Name</label>
                <input type="text"
                    value={this.state.name}
                    onChange={(e) => this.setState({ name: e.currentTarget.value })} />
                <ShowErrors value={this.state.name} validators={this.nameVals} />

                <label>Email</label>
                <input type="text" ref={(r) => this.emailRef = r} />

                <button>Submit</button>
            </form>
        );
    }
}
export default Checkout;