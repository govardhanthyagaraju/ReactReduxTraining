import React from 'react';
import Card from './Card';
import ErrorBoundary from './ErrorBoundary';

class Product extends React.Component {
    checkStock() {
        if (this.props.pData.productStock) {
            return (
                <button className="btn btn-sm btn-primary"
                    onClick={() => this.props.btnClick()}>Add To Cart</button>
            );
        }
        return (
            <p className="alert alert-danger">Out of stock</p>
        );
    }

    render() {
        const { pData, cCode } = this.props;

        return (
            <ErrorBoundary>
                <Card size="3">
                    <img src={pData.productImage} className="img-thumbnail" />
                    <h4>{pData.productName}</h4>
                    <h5>{cCode} {pData.productPrice}</h5>
                    {this.checkStock()}
                    {/* {
                    pData.productStock ?
                        <button>Add To Cart</button> :
                        <p>Out of stock</p>
                } */}
                </Card>
            </ErrorBoundary>
        );
    }
}
export default Product;