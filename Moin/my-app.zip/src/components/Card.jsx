import React from 'react';
const Card = (props) => {
    return (
        <div className={`col-md-${props.size} text-center shadow-sm my-4 p-2`}>
            {props.children}
        </div>
    );
}
export default Card;