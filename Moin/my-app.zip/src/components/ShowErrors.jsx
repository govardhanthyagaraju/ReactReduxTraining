import React from 'react';
import { findAllErrors } from '../core/validation-service';
import PropTypes from 'prop-types';

function ShowErrors(props) {
    return (
        <div>
            {
                findAllErrors(props.validators, props.value).map(
                    (err, i) => <small key={i}>{err}</small>
                )
            }
        </div>
    );
}
ShowErrors.propTypes = {
    value: PropTypes.any.isRequired,
    validators: PropTypes.object.isRequired
}
export default ShowErrors;