import React, { useState } from 'react';

function CartItem(props) {
    const [qty, changeQty] = useState(props.item.qty);
    return (
        <tr>
            <td>
                <img src={props.item.productImage} height="100" width="100" className="img-thumbnail" />
            </td>
            <td>{props.item.productName}</td>
            <td>{props.code} {props.item.productPrice}</td>
            <td>
                <input type="number" value={qty}
                    onChange={(e) => {
                        changeQty(e.currentTarget.value);
                        props.notifyChange(e.currentTarget.valueAsNumber);
                    }} />
            </td>
            <td>{props.code} {props.item.productPrice * qty}</td>
        </tr>
    )
}
export default CartItem;