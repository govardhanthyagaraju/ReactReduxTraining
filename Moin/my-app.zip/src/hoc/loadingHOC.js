import React from 'react';

const withLoading = (WrappedComponent) => {
    return class LoadingScreen extends React.Component {
        render() {
            if (this.props.loading) {
                return (
                    <div className="spinner-border" role="status">
                        <span className="sr-only">Loading...</span>
                    </div>
                );
            }
            return <WrappedComponent {...this.props} title={'TEST Title'} />
        }
    }
}
export default withLoading;