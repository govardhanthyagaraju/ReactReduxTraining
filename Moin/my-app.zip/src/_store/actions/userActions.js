import * as dataService from '../../core/data-service';
import { environment } from '../../config/env.dev';
import { setLoading } from './commonActions';

export const STORE_USER = 'STORE_USER';
export const REMOVE_USER = 'REMOVE_USER';

const storeUser = (user) => ({
    type: STORE_USER, user
});
const removeUser = () => ({
    type: REMOVE_USER
});

export const signIn = (email, password) => {
    return (dispatch) => {
        dispatch(setLoading(true));
        const data = { email, password, returnSecureToken: true };
        dataService.post(`${environment.SIGN_IN}=${environment.GOOGLE_API_KEY}`, data)
            .then(res => {
                console.log('success', res);
                localStorage.setItem('user', JSON.stringify(res.data));
                dispatch(storeUser(res.data));
                dispatch(setLoading(false));
            })
            .catch(err => {
                console.log('error', err);
                dispatch(setLoading(false));
            });

    }
}
export const signUp = (email, password) => {
    const data = { email, password, returnSecureToken: true };
    dataService.post(`${environment.SIGN_UP}=${environment.GOOGLE_API_KEY}`, data)
        .then(res => {
            console.log('success', res);
        })
        .catch(err => {
            console.log('error', err);

        });
}