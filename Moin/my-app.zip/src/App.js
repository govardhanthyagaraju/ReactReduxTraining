import React from 'react';
import './App.css';
import ProductList from './containers/ProductList';
import Currency from './components/Currency';
import Checkout from './components/Checkout';
import AppRouter from './routes';
import Header from './ui/components/Header';
import { BrowserRouter as Router } from 'react-router-dom';

class App extends React.Component {
  state = {
    currentCurrency: 'INR'
  };

  updateCurrency(code) {
    console.log('code', code);
    this.setState({ currentCurrency: code });
  }

  render() {
    return (
      <Router>
        <Header>
          <Currency changeCurrency={(c) => this.updateCurrency(c)} />
        </Header>
        <main className="container">
          <AppRouter />
        </main>
      </Router>
    );
  }
}

export default App;
