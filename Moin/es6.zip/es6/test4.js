
// classes

class Employee {
    empName;
    constructor() {
        console.log('constructor called');
    }

    addEmpName(name) {
        this.empName = name;
    }
}

const emp = new Employee();
emp.addEmpName('test');
console.log(emp.empName);