
// ajax with callbacks

function ajaxWithCallback(success, fail) {

    setTimeout(() => success('call succeeds'), 3000);

    setTimeout(() => fail('call failed'), 5000);
}

ajaxWithCallback(
    (data) => {
        console.log('success', data);
    },
    (err) => {
        console.log('error', err);
    }
);