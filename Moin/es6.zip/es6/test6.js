
// ajax with promise

function ajaxWithPromise() {
    return new Promise(
        (resolve, reject) => {
            setTimeout(() => resolve('call succeeds'), 3000);

            setTimeout(() => reject('call failed'), 5000);
        }
    );
}

ajaxWithPromise()
    .then(
        (data) => {
            console.log('success', data);
        }
    )
    .catch(
        (err) => {
            console.log('error', err);
        }
    );

async function test() {
    try {
        const data = await ajaxWithPromise();
        console.log('async', data);
    } catch (e) {
        console.log('err', e);
    }
}
test();