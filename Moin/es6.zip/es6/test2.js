
// arrow functions
// => : fat arrow

// function fun_name(){ }
// var fun_name = function(){ }


// lexical scoping
let obj = {
    name: 'test',
    age: 21,
    greeting: function () {
        // let self = this;
        setTimeout(function () {
            console.log('hello ' + this.name);
        }.bind(this), 1000);
    }
}

obj.greeting();


// arrow functions
let myobj = {
    name: 'test',
    age: 21,
    greeting: function () {
        console.log(this);
        setTimeout(() => {
            console.log('hello ' + this.name);
        }, 1000);
    }
}

obj.greeting();

function square(no) {
    return no * no;
}

const square = (no) => no * no;

const test = () => {
    console.log('test 1');
    console.log('test 2');
}

function square(no) {
    return {
        number: no,
        square: no * no
    };
}

const square = (no) => ({
    number: no,
    square: no * no
});