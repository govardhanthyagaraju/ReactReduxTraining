'use strict';

// single valued properties
const name = 'mike';
const age = 21;

const user = {
    name,
    age
};

console.log('user object', user);

// destructuring syntax
const userObj = {
    uName: 'john',
    uAge: 25
};

// userObj.uName
// userObj['uName']
// modules
const { uName } = userObj;
console.log('user name', uName);