'use strict';
console.log('app started');

for (var i = 0; i < 10; i++) {
    (function (j) {

        setTimeout(function () {
            console.log('timeout occured', j);
        }, j * 100);

    })(i);
}

// new variable types
// let & const
for (let i = 0; i < 10; i++) {
    setTimeout(function () {
        console.log('new variables', i);
    }, i * 100);
}

const name = 'test'; // readonly variables
name = 'demo';

console.log('app finished');