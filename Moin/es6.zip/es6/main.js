import div, { add } from './test7';
//import * as mathObj from './test7';
// import div from './test7';

add(1, 2);
div(3, 4);
//mathObj.mul(4, 5);