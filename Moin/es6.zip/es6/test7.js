//modules

const add = (a, b) => console.log('sum', a + b);

const sub = (a, b) => console.log('sub', a - b);

const mul = (a, b) => console.log('mul', a * b);

const div = (a, b) => console.log('div', a / b);


export {
    add, sub, mul
}

export default div;