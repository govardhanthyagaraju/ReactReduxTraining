
// template/string literals

const firstname = 'john';
const lastname = "doe";

const msg = `hello!! ${firstname.toUpperCase()} ${lastname} this is some very long text which 
is going really very long and longggggggggggggg`;
console.log(msg);